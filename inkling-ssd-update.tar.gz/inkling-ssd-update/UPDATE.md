# Inkling SSD update, 2026-09-19 (11 Ubuntu boxes, addresses discovered)

## Apply (2 minutes, on any Linux machine with the SSD plugged in)

    tar xzf inkling-ssd-update.tar.gz && cd inkling-ssd-update
    sudo ./apply-update.sh /media/$USER/<ssd>        # the folder that holds inkling-deploy/ and inkling/

Find the mount point with `lsblk -f` or `df -h`. A different number of boxes:
`sudo ./apply-update.sh /media/$USER/<ssd> 10`.

It adds and replaces files under `inkling-deploy/` (about 20 MB), rewrites
`fleet.env` for 11 boxes with address discovery on (the old file is saved as
`fleet.env.before-update`) and verifies every file. The 521 GB model export and
everything else on the SSD are untouched.

Then, on every box, in any order, each with its own number 0..10:

    sudo /media/$USER/<ssd>/inkling-deploy/install.sh <rank>

Rank 0 is the box clients talk to. Boxes already installed from the old state:
run the installer on them again with the same rank.

## What it changes

1. **Addresses are discovered.** No list of IPs. Each box runs a small beacon
   that announces its rank on the LAN and keeps `inkling-rank-<n>` names current
   in `/etc/hosts`; ranks dial each other by name. The boxes keep whatever
   addresses they have, DHCP included, the installer never touches the network,
   and an address that changes is followed within seconds. Needs all boxes on one
   switch. `python3 <ssd>/inkling-deploy/fleet/beacon.py --show` lists who is
   where, from any machine on that switch. (Fixed addresses remain possible:
   see the top of `apply-update.sh`.)
2. **Fleet size.** The SSD was set up for 12 boxes; with 11 present the pipeline
   would wait forever for a rank 11 holding the output head. Now 11: 6 of the 66
   layers per box, ranks 0 to 10.
3. **`libOpenCL.so.1`.** OpenVINO's library needs it, a default Ubuntu install
   often lacks it, and without it the binary does not start at all. Adds the
   38 KB package; the installer installs it when missing.
4. **New binary (`ea7a54ed`).** Rank 0 reconnects by itself after a box behind
   it restarts, and an idle pipeline no longer rebuilds itself every 15 minutes.
5. **Installer.** Tests that the binary starts before doing anything slow (needs
   Ubuntu 24.04 or newer); caps the iGPU's layers by the box's RAM (3 on 64 GB);
   opens the fleet's ports if `ufw` is on; `status.sh` shows the fleet and says
   when a box is swapping.
