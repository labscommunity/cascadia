# Inkling SSD update, 2026-09-19 (11 Ubuntu boxes)

## Apply (2 minutes, on any Linux machine with the SSD plugged in)

    tar xzf inkling-ssd-update.tar.gz && cd inkling-ssd-update
    sudo ./apply-update.sh /media/$USER/<ssd>        # the folder that holds inkling-deploy/ and inkling/

Find the mount point with `lsblk -f` or `df -h`. If the fleet is not 11 boxes,
add the number: `sudo ./apply-update.sh /media/$USER/<ssd> 10`.

It adds and replaces files under `inkling-deploy/` (about 20 MB), sets the
fleet size in `fleet.env` (any addresses you edited are kept; the old file is
saved as `fleet.env.before-update`) and verifies every file. The 521 GB model
export and everything else on the SSD are untouched. Boxes already installed
from the old state: run the installer on them again, with the same rank.

## Why it is needed

1. **Fleet size.** The SSD was set up for 12 boxes. The layers are split
   evenly over `TOTAL` in `fleet.env`; with 12 configured and 11 present, the
   pipeline would wait forever for a rank 11 holding the output head. Now 11:
   6 of the 66 layers per box, ranks 0 to 10.
2. **`libOpenCL.so.1`.** OpenVINO's library needs it, a default Ubuntu install
   often lacks it, and without it the binary does not start at all (CPU ranks
   included). Adds the 38 KB package; the installer installs it when missing.
3. **New binary (`ea7a54ed`).** Rank 0 reconnects by itself after a box behind
   it restarts (no manual rank 0 restart), and an idle pipeline no longer
   rebuilds itself every 15 minutes.
4. **Installer.** Tests that the binary starts before doing anything slow
   (needs Ubuntu 24.04 or newer); picks the network port that has link (the
   old one could pick an unplugged port on a two-port box); on a switch with
   no DHCP server it makes the port static only, because "DHCP + static" does
   not stay up there; caps the iGPU's layers by the box's RAM (3 on 64 GB);
   `status.sh` says when a box is swapping.
